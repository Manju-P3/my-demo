import XCTest

class DemoClass: BaseTestClass{
    
    func testSample()
    {
        
      
    }
}

