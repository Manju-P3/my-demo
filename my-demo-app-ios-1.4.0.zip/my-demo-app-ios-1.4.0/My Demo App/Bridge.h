//
//  Bridge.h
//  My Demo App
//

#ifndef Bridge_h
#define Bridge_h

#include <TestFairy/TestFairy.h>

#endif /* Bridge_h */
