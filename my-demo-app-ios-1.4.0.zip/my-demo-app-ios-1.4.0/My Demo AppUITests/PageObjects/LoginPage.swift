import Foundation
import XCTest

class LoginClass {
    let app: XCUIApplication
    let usernameField: XCUIElement
    let passwordField: XCUIElement
    let loginButton: XCUIElement
    
    init(app: XCUIApplication) {
        self.app = app
        usernameField = app.textFields["entername"]
        passwordField = app.secureTextFields["pwd"]
        loginButton = app.buttons["Login"]
    }
    
    func login(username: String, password: String) {
        usernameField.tap()
        usernameField.typeText(username)
        
        passwordField.tap()
        passwordField.typeText(password)
        
        usernameField.tap()
        loginButton.tap()
    }
    
}
