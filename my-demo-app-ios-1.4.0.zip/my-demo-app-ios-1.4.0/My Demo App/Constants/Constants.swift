//
//  Constants.swift
//  My Demo App
//
//  Created by Mubashir on 22/09/21.
//

import Foundation

var cartCount = 0
