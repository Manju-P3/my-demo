import Foundation
import XCTest

class AddressPageClass {
    
    let app: XCUIApplication
    let fullName: XCUIElement
    let AddLine1: XCUIElement
    let AddLine2: XCUIElement
    let City: XCUIElement
    let ZipCode: XCUIElement
    let State: XCUIElement
    let Country: XCUIElement
    let PaymentButton: XCUIElement
    
    
    init(app: XCUIApplication) {
        self.app = app
        fullName = app.otherElements["ShippingAddress-screen"].scrollViews.otherElements.textFields["Rebecca Winter"]
        AddLine1 = app.otherElements["ShippingAddress-screen"].scrollViews.otherElements.textFields["Mandorley 112"]
        AddLine2 = app.scrollViews.textFields["Entrance 1"]
        City = app.scrollViews.textFields["Truro"]
        ZipCode = app.scrollViews.textFields["89750"]
        State = app.scrollViews.textFields["Cornwall"]
        Country = app.scrollViews.textFields["United Kingdom"]
        PaymentButton = app.buttons["To Payment"]
    }
    
    
    func address(Rebecca: String, Add1: String,Ent: String, city: String,zipCode: String, state: String,country: String)
    {
        fullName.tap()
        fullName.typeText(Rebecca)
        
        AddLine1.tap()
        AddLine1.typeText(Add1)
        
        AddLine2.tap()
        AddLine2.typeText(Ent)
        
        AddLine1.tap()
        City.tap()
        City.typeText(city)
        
        AddLine1.tap()
        ZipCode.tap()
        ZipCode.typeText(zipCode)
        
        AddLine1.tap()
        State.tap()
        State.typeText(state)
        
        AddLine1.tap()
        Country.tap()
        Country.typeText(country)
        
        AddLine1.tap()
        PaymentButton.tap()
    }
}
