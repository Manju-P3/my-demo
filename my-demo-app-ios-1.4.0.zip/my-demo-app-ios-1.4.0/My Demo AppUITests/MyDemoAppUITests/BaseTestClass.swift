import XCTest

class BaseTestClass: XCTestCase{
    
    let app = XCUIApplication()
    
    
    // Setup
    override func setUp()
    {
        continueAfterFailure = false
        app.launch()
    }
    
    
    
    //Tear Down
    override func tearDown()
    {
        takeScreenshot(name: "end of test case")
//        app.terminate()
    }
    
    
    
    
    
    // To Take ScreenShot
    func takeScreenshot(name: String) {
      let fullScreenshot = XCUIScreen.main.screenshot()
      let screenshot = XCTAttachment(uniformTypeIdentifier: "public.png", name: "Screenshot-\(name)-\(UIDevice.current.name).png", payload: fullScreenshot.pngRepresentation, userInfo: nil)
      screenshot.lifetime = .keepAlways
      add(screenshot)
    }
    
}
