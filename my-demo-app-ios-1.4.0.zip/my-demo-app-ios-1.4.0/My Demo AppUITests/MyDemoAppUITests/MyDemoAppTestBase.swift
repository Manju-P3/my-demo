import XCTest
import Foundation

class MyDemoAppTestBase: XCTestCase {
    let app = XCUIApplication()
    override func setUp() {
        continueAfterFailure = false
        app.launch()
    }
    func testExample(){
       
//        let approxtotaiItemcount = app.collectionViews.cells.count
        
        //var approxtotaiItemcountafterswipe1 = 0
        
//        var itemArray = [String]()
//
//
//            app.swipeUp()
//
//        sleep(2)
//
//            let approxtotaiItemcountafterswipe = app.collectionViews.cells.count
//
////            if approxtotaiItemcount >= approxtotaiItemcountafterswipe
////            {
////
////                app.swipeUp()
////
////            }
////
////             approxtotaiItemcountafterswipe1 = app.collectionViews.cells.count
////
////            if approxtotaiItemcountafterswipe == approxtotaiItemcountafterswipe1
////            {
////
////                break
////
////            }
//
//
//
//
//
//        for i in 0..<approxtotaiItemcountafterswipe
//        {
//
//            itemArray.append(app.collectionViews.cells.element(boundBy: i).staticTexts.element(boundBy: 1).label)
//
//        }
//
//        print(itemArray)
//
        app.collectionViews.children(matching: .cell).containing(.staticText,identifier: "Sauce Lab Bike Light").element(boundBy: 0).tap()
        app.scrollViews.otherElements.containing(.staticText, identifier: "Sauce Lab Bike Light").element.swipeUp()
        app.scrollViews.otherElements.staticTexts["Add To Cart"].tap()
        app.buttons["Cart-tab-item"].tap()
        app.otherElements.buttons["Proceed To Checkout"].tap()
        
        //Login
        app.scrollViews.otherElements.staticTexts["bob@example.com"].tap()
        app.buttons["Login"].tap()
        
        // address
        let Rebecca = app.otherElements["ShippingAddress-screen"].scrollViews.otherElements.textFields["Rebecca Winter"]
        Rebecca.tap()
        //sleep(3)
        Rebecca.typeText("ZuciTech")
        
        let Add1 = app.otherElements["ShippingAddress-screen"].scrollViews.otherElements.textFields["Mandorley 112"]
        Add1.tap()
        Add1.typeText("bangalore")

        let Ent = app.scrollViews.textFields["Entrance 1"]
        Ent.tap()
        Ent.typeText("Not Applicable")
        
        sleep(3)
        
        let city = app.scrollViews.textFields["Truro"]
        city.tap()
        city.typeText("Bangalore")

        let state = app.scrollViews.textFields["Cornwall"]
        state.tap()
        state.typeText("karnataka")
        sleep(5)
        
//        let zipCode = app.scrollViews.
//        zipCode.tap()
//        zipCode.typeText("33212")
        
        let country = app.scrollViews.textFields["United Kingdom"]
        country.tap()
        country.typeText("India")
        
        let paymentButton = app.scrollViews.buttons["To Payment"]
        paymentButton.tap()
   }
    
    
    override func tearDown() {
        
    }
}
