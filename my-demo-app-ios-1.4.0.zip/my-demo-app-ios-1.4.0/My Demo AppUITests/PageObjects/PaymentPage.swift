import Foundation
import XCTest

class PaymentPageClass {
    let app: XCUIApplication
    let fullName: XCUIElement
    let cardNumber: XCUIElement
    let expiryDate: XCUIElement
    let securityCode: XCUIElement
    let ReviewButton: XCUIElement
    
    init(app: XCUIApplication)
    {
        self.app = app
        fullName = app.textFields["Maxim Winter"]
        cardNumber = app.textFields["3258 1265 7568 7896"]
        expiryDate = app.textFields["03/25"]
        securityCode = app.textFields["123"]
        ReviewButton = app.staticTexts["Review Order"]
    }
    
    func payment(Fname: String, cNumber: String, eDate: String, securityC: String)
    {
        
        fullName.tap()
        fullName.typeText(Fname)
        app.swipeUp()
        
        cardNumber.tap()
        cardNumber.typeText(cNumber)
        
        fullName.tap()
        
        expiryDate.tap()
        expiryDate.typeText(eDate)
        
        fullName.tap()
        securityCode.tap()
        securityCode.typeText(securityC)
        
        fullName.tap()
        ReviewButton.tap()
    }
    
}

