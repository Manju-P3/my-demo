import XCTest

class PageObject {
    
    let app = XCUIApplication()
    func productList() -> Int
    {
        sleep(5)
        var noOfCells = app.collectionViews.cells.count
        if noOfCells != 6
        {
            app.swipeUp()
            let noUOfCells = app.collectionViews.cells.count
            noOfCells = noUOfCells
        }
        return noOfCells
    }
    
    func productS()
    {
        var emptyDict = [String:Float]()
        app.swipeUp()
        for i in 0...5
        {
            let productNamed = app.collectionViews.cells.element(boundBy: i).staticTexts.element(boundBy: 0).label
            let productPrice = app.collectionViews.cells.element(boundBy: i).staticTexts.element(boundBy: 1).label
            let trimmedP = productPrice.components(separatedBy: " ")
            emptyDict[productNamed] = Float(trimmedP[1])
        }
        let sortedDictByKey = emptyDict.sorted{ $0.value < $1.value }
//        emptyDict.values.sort(by: { $0 < $1 })
        print(sortedDictByKey)
        
        let getPnmae =  sortedDictByKey[1]
        app.collectionViews.cells.staticTexts[getPnmae.key].tap()
        _ = app.scrollViews.otherElements.staticTexts["Add To Cart"].waitForExistence(timeout: 10)
        app.scrollViews.otherElements.staticTexts["Add To Cart"].tap()
    }
    
    
    func proceedToCheckout() -> String
    {
        app.buttons["Cart-tab-item"].tap()
        let productName = app.tables.cells.element(boundBy: 0).staticTexts.element(boundBy: 0).label
        _ = app.otherElements.buttons["ProceedToCheckout"].waitForExistence(timeout: 10)
        app.otherElements.buttons["ProceedToCheckout"].tap()
        return productName
    }
    
    func loginView()
    {
        let loginScreen = LoginClass(app: app)
        loginScreen.login(username: "bob@example.com", password: "10203040")
    }
    
    func enterAddress()
    {
        let address = AddressPageClass(app: app)
        address.address(Rebecca: "Fullname", Add1: "JPNagar", Ent: "3rd Phase", city: "Bangalore", zipCode: "589034", state: "Karnataka", country: "India")
    }
    
    func paymentPage()
    {
        let payPage = PaymentPageClass(app: app)
        payPage.payment(Fname: "someName", cNumber: "2345 3221 2334 4456", eDate: "03/45", securityC: "123")
    }
    
    func checkOrder()
    {
        let bikeLight = proceedToCheckout()
        
        let productnameinCheckout = app.tables.cells.element(boundBy: 0).staticTexts.element(boundBy: 0).label
        XCTAssertEqual(bikeLight, productnameinCheckout)
    }
    func placeOrder()
    {
        app.buttons["Place Order"].tap()
        XCTAssertTrue(app.staticTexts["Thank you for your order "].exists)
    }
    func continueShopping()
    {
        
    }

}



//Address

//        let Rebecca = app.otherElements["ShippingAddress-screen"].scrollViews.otherElements.textFields["Rebecca Winter"]
//        Rebecca.tap()
//        Rebecca.typeText("ZuciTech")
//
//        let Add1 = app.otherElements["ShippingAddress-screen"].scrollViews.otherElements.textFields["Mandorley 112"]
//        Add1.tap()
//        Add1.typeText("bangalore")
//
//        let Ent = app.scrollViews.textFields["Entrance 1"]
//        Ent.tap()
//        Ent.typeText("Bangalore")
//
//        Add1.tap()
//        app.swipeUp()
//
//        let city = app.scrollViews.textFields["Truro"]
//        city.tap()
//        city.typeText("Bangalore")
//
//        Add1.tap()
//
//        let zipCode = app.scrollViews.textFields["89750"]
//        zipCode.tap()
//        zipCode.typeText("33212")
//
//        let state = app.scrollViews.textFields["Cornwall"]
//        state.tap()
//        state.typeText("karnataka")
//
//        Add1.tap()
//        let country = app.scrollViews.textFields["United Kingdom"]
//        country.tap()
//        country.typeText("United Kingdom")
//
//        Add1.tap()
//        sleep(3)
//        app.buttons["To Payment"].tap()



//func addToCart()
//{
//        let array1 =5
//        for i in 0..<array1.count
//        {
//            if(i == 1){
//                app.collectionViews.children(matching: .cell).element(boundBy: 1).images["backBag"].tap()
//            }
//        }
////        print(array1)
////        let array2 = app.collectionViews.cells.element(boundBy: 1).staticTexts.element(boundBy: 1).label
////        let trimmed = array2.components(separatedBy: " ")
////        let lowestPrice = Float(trimmed[1])!
//        //app.collectionViews.children(matching: .cell).containing(.staticText, identifier: "Sauce Lab Bike Light").element(boundBy: 0).tap()
////        print(lowestPrice)
//
    
//}


//
//        sleep(2)
//       var productNameofssmall = sortedDictByKey.
//            let productName = app.collectionViews.cells.element(boundBy: i).staticTexts.element(boundBy: 0).label
//        print("Products price \(trimmedP) and Products \(productName)")
//        }
//        array.sort()
//        print(array)
//
//        return array
