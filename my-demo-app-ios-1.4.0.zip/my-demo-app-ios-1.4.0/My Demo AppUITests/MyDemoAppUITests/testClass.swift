import XCTest

class pageTestClass: BaseTestClass
{
    let products = PageObject()
    
    func testCountNoproducts()
    {
        let valuepr = products.productList()
        XCTAssertEqual(valuepr, 6)
        print(valuepr)
    }
    
    func test01_Products()
    {
        products.productS()
        
    }
    
    func test02_addToCart()
    {
        products.productS()
        products.proceedToCheckout()
        let loginScreen = LoginClass(app: app)
        XCTAssertTrue(loginScreen.usernameField.exists)
        takeScreenshot(name: "Login Page")
        loginScreen.login(username: "bob@example.com", password: "10203040")
    }
    
    func test03_NoUserCredential()
    {
        products.productS()
        products.proceedToCheckout()
        let loginScreen = LoginClass(app: app)
        loginScreen.login(username: "", password: "")
        XCTAssertTrue(app.alerts["Validation Error!"].scrollViews.otherElements.staticTexts["Username is required"].exists)
        takeScreenshot(name: "NoLoginCredential")
    }
    
    func testProduct()
    {
        products.productS()
        products.proceedToCheckout()
        products.loginView()
        products.enterAddress()
        products.paymentPage()
        sleep(10)
        products.placeOrder()
        sleep(10)
        takeScreenshot(name: "Place Order")
    }
}
